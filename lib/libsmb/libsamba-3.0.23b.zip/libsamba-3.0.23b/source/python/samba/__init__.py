"""samba

Various Python modules for interfacing to Samba.

Try using help() to examine their documentation.
"""

